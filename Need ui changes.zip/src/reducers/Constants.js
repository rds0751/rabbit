//Base URL
export const BASE_URL =
  "http://whitelabel-nft-lb-dev-1838936337.us-east-1.elb.amazonaws.com:3004";
export const BASE_URL2 =
  "http://whitelabel-nft-lb-dev-1838936337.us-east-1.elb.amazonaws.com:3002";

export const WEB_APP_USER_WALLET_ADDRESS = "WEB_APP_USER_WALLET_ADDRESS";
export const ADD_WALLET = "ADD_WALLET";
export const LOGGED_IN_UER_DETAILS = "LOGGED_IN_UER_DETAILS";

export const GET_ERRORS = "GET_ERRORS";
export const ALL_USERS = "ALL_USERS";
export const OPEN_NOTIFICATION = "OPEN_NOTIFICATION";
export const REDIRECT_URL="REDIRECT_URL"
export const OPEN_WALLET = "OPEN_WALLET";

export const ADD_USER = "ADD_USER"; // --- WE ARE NOT USING THIS
