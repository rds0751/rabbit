import React from "react";
import UpperMyItems from "../../common/components/UpperMyItems";
// import { Link } from "react-router-dom";
// import UpperMyItems from "./UpperMyItems";

function MyItems() {
  return (
    <>
      <UpperMyItems />
      <h1>hello</h1>
    </>
  );
}

export default MyItems;
