export const CollectionTile_Api = [
  {
    id: "1",
    image:
      "https://semidotinfotech.com/blog/wp-content/uploads/2021/05/A-Guide-to-Develop-NFT-Marketplace.jpg",
    title: "Abstract Illusions",
    number: "4",
  },
  {
    id: "1",
    image:
      "https://semidotinfotech.com/blog/wp-content/uploads/2021/05/A-Guide-to-Develop-NFT-Marketplace.jpg",
    title: "Abstract Illusions",
    number: "4",
  },
  {
    id: "1",
    image:
      "https://semidotinfotech.com/blog/wp-content/uploads/2021/05/A-Guide-to-Develop-NFT-Marketplace.jpg",
    title: "Abstract Illusions",
    number: "4",
  },
  {
    id: "1",
    image:
      "https://semidotinfotech.com/blog/wp-content/uploads/2021/05/A-Guide-to-Develop-NFT-Marketplace.jpg",
    title: "Abstract Illusions",
    number: "4",
  },
];
