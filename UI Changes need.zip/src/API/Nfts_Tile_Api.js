export const Nfts_Tile_Api = [
  {
    id: "1",
    image:
      "https://semidotinfotech.com/blog/wp-content/uploads/2021/05/A-Guide-to-Develop-NFT-Marketplace.jpg",
    title: "Jelly Fish",
    price: "3.2 ETH",
    maxPrice: "0.48 ETH",
    daysLeft: 5,
  },
  {
    id: "1",
    image:
      "https://semidotinfotech.com/blog/wp-content/uploads/2021/05/A-Guide-to-Develop-NFT-Marketplace.jpg",
    title: "Jelly Fish",
    price: "3.2 ETH",
    maxPrice: "0.48 ETH",
    daysLeft: 5,
  },
  {
    id: "1",
    image:
      "https://semidotinfotech.com/blog/wp-content/uploads/2021/05/A-Guide-to-Develop-NFT-Marketplace.jpg",
    title: "Jelly Fish",
    price: "3.2 ETH",
    maxPrice: "0.48 ETH",
    daysLeft: 5,
  },
  {
    id: "1",
    image:
      "https://semidotinfotech.com/blog/wp-content/uploads/2021/05/A-Guide-to-Develop-NFT-Marketplace.jpg",
    title: "Jelly Fish",
    price: "3.2 ETH",
    maxPrice: "0.48 ETH",
    daysLeft: 5,
  },
  {
    id: "1",
    image:
      "https://semidotinfotech.com/blog/wp-content/uploads/2021/05/A-Guide-to-Develop-NFT-Marketplace.jpg",
    title: "Jelly Fish",
    price: "3.2 ETH",
    maxPrice: "0.48 ETH",
    daysLeft: 5,
  },
  {
    id: "1",
    image:
      "https://semidotinfotech.com/blog/wp-content/uploads/2021/05/A-Guide-to-Develop-NFT-Marketplace.jpg",
    title: "Jelly Fish",
    price: "3.2 ETH",
    maxPrice: "0.48 ETH",
    daysLeft: 5,
  },
  {
    id: "1",
    image:
      "https://semidotinfotech.com/blog/wp-content/uploads/2021/05/A-Guide-to-Develop-NFT-Marketplace.jpg",
    title: "Jelly Fish",
    price: "3.2 ETH",
    maxPrice: "0.48 ETH",
    daysLeft: 5,
  },
  {
    id: "1",
    image:
      "https://semidotinfotech.com/blog/wp-content/uploads/2021/05/A-Guide-to-Develop-NFT-Marketplace.jpg",
    title: "Jelly Fish",
    price: "3.2 ETH",
    maxPrice: "0.48 ETH",
    daysLeft: 5,
  },
  {
    id: "1",
    image:
      "https://semidotinfotech.com/blog/wp-content/uploads/2021/05/A-Guide-to-Develop-NFT-Marketplace.jpg",
    title: "Jelly Fish",
    price: "3.2 ETH",
    maxPrice: "0.48 ETH",
    daysLeft: 5,
  },
  {
    id: "1",
    image:
      "https://semidotinfotech.com/blog/wp-content/uploads/2021/05/A-Guide-to-Develop-NFT-Marketplace.jpg",
    title: "Jelly Fish",
    price: "3.2 ETH",
    maxPrice: "0.48 ETH",
    daysLeft: 5,
  },
  {
    id: "1",
    image:
      "https://semidotinfotech.com/blog/wp-content/uploads/2021/05/A-Guide-to-Develop-NFT-Marketplace.jpg",
    title: "Jelly Fish",
    price: "3.2 ETH",
    maxPrice: "0.48 ETH",
    daysLeft: 5,
  },
  {
    id: "1",
    image:
      "https://semidotinfotech.com/blog/wp-content/uploads/2021/05/A-Guide-to-Develop-NFT-Marketplace.jpg",
    title: "Jelly Fish",
    price: "3.2 ETH",
    maxPrice: "0.48 ETH",
    daysLeft: 5,
  },
];
