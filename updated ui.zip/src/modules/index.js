/**
 * Created by Ayush Kulshrestha on 18/09/2019.
 */

//export all the components from index file -


export {default as Login} from "./login";
export {default as SignUp} from "./signup";

