import React from "react";
// import { Link } from "react-router-dom";
import UpperMyItems from "../../common/components/UpperMyItems";

function MyItems() {
  return (
    <>
      <UpperMyItems />
    </>
  );
}

export default MyItems;
